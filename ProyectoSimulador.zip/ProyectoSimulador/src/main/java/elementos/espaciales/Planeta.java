package elementos.espaciales;

import elementos.ObjetoObservado;

public class Planeta extends ObjetoObservado{
    public Planeta(String descripcion) {
        super(descripcion);
    }
    
    @Override
    public boolean esDestino() {
        return true;
    }
}
