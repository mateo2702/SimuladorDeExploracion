package elementos.espaciales;

import elementos.ObjetoObservado;

public class Meteorito extends ObjetoObservado {
    public Meteorito(String descripcion) {
        super(descripcion);
    }
}
