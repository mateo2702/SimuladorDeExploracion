package elementos.espaciales;

import elementos.ObjetoObservado;

public class ElementoPasajero extends ObjetoObservado{
    public ElementoPasajero(String descripcion) {
        super(descripcion);
    }
}
