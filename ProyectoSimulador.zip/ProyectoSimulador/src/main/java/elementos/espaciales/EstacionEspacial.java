package elementos.espaciales;

import elementos.ObjetoObservado;

public class EstacionEspacial extends ObjetoObservado{
    public EstacionEspacial(String descripcion) {
        super(descripcion);
    }
    
    @Override
    public boolean esDestino() {
        return true;
    }
}
