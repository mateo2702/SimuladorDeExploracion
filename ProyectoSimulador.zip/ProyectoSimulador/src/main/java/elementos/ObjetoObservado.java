package elementos;

import javax.swing.JOptionPane;

public abstract class ObjetoObservado {
    private String nombre;
    private String descripcion;
    private boolean visto; // Nuevo atributo para rastrear si el objeto ha sido visto

    public ObjetoObservado(String descripcion) {
        this.descripcion = descripcion;
        this.visto = false; // Inicialmente, el objeto no ha sido visto
    }

    public String getDescripcion() {
        return descripcion;
    }

    public String getNombre() {
        return nombre;
    }

    public boolean isVisto() {
        return visto;
    }

    public boolean esDestino() {
        return false;
    }

    public void mostrarInformacion() {
        JOptionPane.showMessageDialog(null, descripcion, "Objeto Observado",
                JOptionPane.INFORMATION_MESSAGE);
        visto = true; // Marca el objeto como visto después de mostrarlo
    }

    // Agrega un método para verificar si el objeto ha sido visto
    public boolean haSidoVisto() {
        return visto;
    }

    public void marcarComoVisto() {
        this.visto = true;
    }
}

