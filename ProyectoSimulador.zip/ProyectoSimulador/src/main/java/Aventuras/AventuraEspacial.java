package Aventuras;

import elementos.espaciales.*;

public final class AventuraEspacial extends Aventura{
    
    public AventuraEspacial() {
        super("Aventura Espacial", "Un viaje hacia un destino desconocido");
        inicializarObjetos();
    }

    @Override
    void inicializarObjetos() {
        objetosObservados.add(new Planeta("Un planeta misterioso con una atmósfera extraña"));
        objetosObservados.add(new Planeta("Un mundo cubierto de nieve y hielo"));
        objetosObservados.add(new EstacionEspacial("Una estación en órbita que puedes visitar"));
        objetosObservados.add(new ElementoPasajero("Un grupo de asteroides flotando en el espacio"));
        // Agregar más objetos observados en el espacio
    }
}
