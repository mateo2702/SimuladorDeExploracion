package Aventuras;

import elementos.*;

import java.util.ArrayList;
import java.util.Random;

public abstract class Aventura {
    String nombre;
    String descripcion;
    ArrayList<ObjetoObservado> objetosObservados;

    Aventura(String nombre, String descripcion) {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.objetosObservados = new ArrayList<>();
    }
    
    abstract void inicializarObjetos();

    public String getDescripcion() {
        return descripcion;
    }

    public String getNombre() {
        return nombre;
    }

    public ArrayList<ObjetoObservado> getObjetosObservados() {
        return objetosObservados;
    }
    
    public ObjetoObservado generarObjetoAleatorio() {
        Random random = new Random();
        int indice = random.nextInt(objetosObservados.size());
        return objetosObservados.get(indice);
    }
}
