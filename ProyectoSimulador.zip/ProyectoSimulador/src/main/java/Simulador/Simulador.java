package Simulador;

import Aventuras.*;
import elementos.ObjetoObservado;
import elementos.espaciales.*;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Simulador {

    private static boolean continuarExplorando = true;
    private static Timer timer;

    public static void main() {
        mostrarBienvenida();
        iniciarSimulador();
    }

    static void mostrarBienvenida() {
        JOptionPane.showMessageDialog(null, "Bienvenido al Simulador de Exploración!\nPresiona Iniciar para empezar el simulador.",
                "Simulador de Exploración", JOptionPane.INFORMATION_MESSAGE);
    }

    static void iniciarSimulador() {
        int opcionAventura = mostrarMenuAventuras();
        if (opcionAventura == -1) {
            return; // El jugador canceló la selección
        }

        Aventura aventura = crearAventura(opcionAventura);
        mostrarHistoriaAventura(aventura);

        // Configura el temporizador para mostrar objetos cada 5 segundos
        timer = new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (continuarExplorando) {
                    ObjetoObservado objeto = aventura.generarObjetoAleatorio();
                    mostrarObjeto(objeto, aventura);
                }
            }
        });

        timer.setRepeats(true);
        timer.start();
        
        while (continuarExplorando) {
            // No hagas nada aquí, simplemente espera a que el usuario interactúe
        }
    }

    static int mostrarMenuAventuras() {
        Object[] opciones = {"Espacio"};
        return JOptionPane.showOptionDialog(null, "Elige una aventura para explorar:", "Selecciona una aventura",
                JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, opciones, opciones[0]);
    }

    static Aventura crearAventura(int opcionAventura) {
        return switch (opcionAventura) {
            case 0 -> new AventuraEspacial();
            default -> null;
        };
    }

    static void mostrarHistoriaAventura(Aventura aventura) {
        JOptionPane.showMessageDialog(null, "Estás en una emocionante aventura espacial.\n" +
                aventura.getDescripcion() + "\nPresiona Comenzar para empezar la exploración.",
                "Historia de la Aventura", JOptionPane.INFORMATION_MESSAGE);
    }

    static void mostrarObjeto(ObjetoObservado objeto, Aventura aventura) {
        // Verifica si el objeto ha sido visto antes
        if (objeto.haSidoVisto()) {
            return;
        }

        // Marca el objeto como visto
        objeto.marcarComoVisto();

        // Detiene el temporizador temporalmente para que el usuario pueda interactuar con el objeto
        timer.stop();

        if (objeto.esDestino()) {
            int opcion = JOptionPane.showConfirmDialog(null,
                    "¿Quieres visitar " + objeto.getDescripcion() + "?", "Visitar Destino",
                    JOptionPane.YES_NO_OPTION);

            if (opcion == JOptionPane.YES_OPTION) {
                explorarDestino(objeto);
            }
        } else if (objeto instanceof ElementoPasajero) {
            JOptionPane.showMessageDialog(null, objeto.getDescripcion(), "Descripción del Objeto",
                    JOptionPane.INFORMATION_MESSAGE);
        }

        // Reinicia el temporizador para mostrar el siguiente objeto
        timer.restart();
    }

    static void explorarDestino(ObjetoObservado destino) {
        JOptionPane.showMessageDialog(null, "Has llegado a " + destino.getDescripcion() + "!\n" +
                "Mira a tu alrededor y explora el destino.", "¡Explorando Destino!",
                JOptionPane.INFORMATION_MESSAGE);

        // Lógica para explorar el destino, puedes agregar más interacciones aquí

        JOptionPane.showMessageDialog(null, "¡Has explorado " + destino.getDescripcion() + "!\n" +
                "Ahora puedes regresar y continuar tu viaje.", "Fin de la Exploración del Destino",
                JOptionPane.INFORMATION_MESSAGE);
    }
}

