package Simulador;

public class ProyectRun {
    
    public static void main(String[] args) {
        Simulador.main();
    }
    
}
